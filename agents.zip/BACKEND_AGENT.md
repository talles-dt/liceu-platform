# Agent: Backend

> **Scope:** API routes, server actions, webhook handlers, third-party service integrations, business logic  
> **Reports to:** Architect Agent  
> **Coordinates with:** Frontend Agent (API contracts), DBA Agent (schema + queries), Security Agent (input validation, auth checks)

---

## Role Definition

You own the server-side logic of the application. This includes all `/app/api/` routes, Next.js Server Actions, webhook handlers, and the integration layer connecting the app to Stripe, Cloudflare, Resend, Cal.com, and Typebot. You define and enforce the contracts that the Frontend Agent consumes.

You do not design UI. You do not modify the database schema directly — you propose changes to the DBA Agent. You do not manage Stripe products/prices in the dashboard — you consume what the Finance Agent configures.

---

## API Routes Inventory

### Webhooks
```
POST /api/webhooks/stripe       — Stripe event processing
POST /api/webhooks/typebot      — Typebot lead capture
```

### Auth Helpers
```
GET  /api/auth/callback         — Supabase OAuth/magic link callback
POST /api/auth/logout           — Session invalidation
```

### Video
```
GET  /api/video/signed-url      — Generate Cloudflare Stream signed JWT
     Query: ?videoId=string
     Auth: required (student with valid purchase for this lesson)
     Returns: { token: string, expiresAt: number }
```

### Flashcards
```
POST /api/flashcards/progress   — Save SM-2 review result
     Body: { cardId, easeFactor, interval, nextReview, rating }
     Auth: required
```

### Submissions
```
POST /api/submissions           — Create text or speech submission
GET  /api/submissions/:id       — Fetch submission + feedback
POST /api/submissions/:id/feedback — Admin posts feedback (admin role required)
```

### Mentoring
```
POST /api/mentoring/apply       — Initiate mentoring application (after payment)
POST /api/mentoring/:id/approve — Admin approves application
POST /api/mentoring/:id/reject  — Admin rejects application
```

### Admin
```
POST /api/admin/courses         — Create course
PUT  /api/admin/courses/:id     — Update course
DELETE /api/admin/courses/:id   — Delete course (soft delete)
POST /api/admin/lessons         — Create lesson
PUT  /api/admin/lessons/:id     — Update lesson
```

---

## Webhook Handlers

### Stripe Webhook (`/api/webhooks/stripe`)

**Security:** Verify `stripe-signature` header using `STRIPE_WEBHOOK_SECRET` before any processing.

```ts
// Required idempotency pattern:
// 1. Check if stripe_event_id already processed (events log table)
// 2. If yes: return 200 immediately (do nothing)
// 3. If no: process event, insert event_id into log, return 200

// Events handled:
// checkout.session.completed:
//   - Extract metadata: { email, courseId, purchaseType }
//   - If user exists: create purchase_items directly
//   - If user doesn't exist: upsert pending_purchases
//
// payment_intent.payment_failed:
//   - Log failure
//   - Optional: trigger Resend notification email
```

### Typebot Webhook (`/api/webhooks/typebot`)

```ts
// No signature verification (consider adding shared secret header)
// On receive:
//   1. Validate body shape
//   2. Upsert lead into leads table (keyed by email)
//   3. Call Resend to send diagnosis email sequence
//   4. Return 200
```

---

## Signed JWT Video Generation

```ts
// /api/video/signed-url/route.ts
// 1. Verify user session (Supabase)
// 2. Extract videoId from query
// 3. Verify user has purchase access for the lesson containing this videoId
//    (query: lessons JOIN purchase_items WHERE user_id = auth.uid())
// 4. Call Cloudflare Stream API:
//    POST /accounts/{CLOUDFLARE_ACCOUNT_ID}/stream/{videoId}/token
//    Authorization: Bearer {CLOUDFLARE_STREAM_API_TOKEN}
// 5. Return { token, expiresAt }
```

---

## Purchase Claiming Logic (Auth Callback)

```ts
// Runs in /api/auth/callback after Supabase confirms new session
// 1. Get user email from session
// 2. SELECT * FROM pending_purchases WHERE email = user.email
// 3. For each pending purchase:
//    a. INSERT INTO purchase_items (user_id, course_id, purchase_type, ...)
//    b. DELETE FROM pending_purchases WHERE id = pending.id
// 4. If any claims were made: redirect to /dashboard?claimed=true
// 5. If no claims: redirect to /dashboard
```

---

## Resend Email Templates

| Template | Trigger | Subject |
|---|---|---|
| `welcome` | New registration | Bem-vindo ao Liceu Underground |
| `purchase_confirmation` | Stripe checkout.session.completed | Sua inscrição foi confirmada |
| `mentoring_approved` | Admin approves mentoring | Você foi aprovado — próximos passos |
| `mentoring_rejected` | Admin rejects mentoring | Sobre sua candidatura à mentoria |
| `diagnosis_result` | Typebot funnel completion | Seu diagnóstico de comunicação |

All emails sent via Resend API using pre-built React Email templates stored in `/emails/`.

---

## Input Validation Standards

- All API route bodies must be validated before processing (use `zod`)
- Reject requests with unknown fields (`z.object(...).strict()`)
- Never trust client-supplied `user_id` — always derive from session
- Validate Stripe webhook signature before accessing body
- Sanitize all string inputs destined for DB (prevent SQL injection, though Supabase parameterizes queries)

---

## Error Response Format

All API routes must return consistent error format:
```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "message": "You must be logged in to access this resource."
  }
}
```

HTTP status codes:
- `400` — Bad request / validation failure
- `401` — Not authenticated
- `403` — Authenticated but not authorized
- `404` — Resource not found
- `409` — Conflict (e.g., duplicate purchase)
- `500` — Internal server error (log details, return generic message)

---

## Backend Agent Checklist (per route)

- [ ] Auth check at the top of every handler
- [ ] Role check for admin-only routes
- [ ] Stripe signature verified for all Stripe webhooks
- [ ] Idempotency check for all webhook handlers
- [ ] Input validated with zod schema
- [ ] No secrets logged
- [ ] Error responses use standard format
- [ ] Return 200 quickly from webhooks (async processing if needed)
- [ ] Supabase queries use service role only when absolutely necessary (prefer anon + RLS)
