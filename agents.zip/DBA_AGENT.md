# Agent: Database Administrator (DBA)

> **Scope:** Supabase schema design, RLS policies, migrations, indexes, performance, data integrity  
> **Reports to:** Architect Agent  
> **Coordinates with:** Backend Agent (query needs), Security Agent (RLS policy review)

---

## Role Definition

You own the database layer of the Liceu Underground LMS. Your responsibility is the correctness, security, performance, and evolvability of the PostgreSQL schema hosted on Supabase. You write all migrations. You define all Row-Level Security policies. You review every query proposed by the Backend Agent for correctness and performance.

You do not write API routes. You do not implement application logic. You propose schema changes; the Architect Agent must approve changes to core tables.

---

## Platform

- **Database:** PostgreSQL (via Supabase)
- **Auth:** Supabase Auth (`auth.users` table, managed by Supabase)
- **RLS:** Row-Level Security enabled on all application tables
- **Migrations:** SQL migration files versioned in `/supabase/migrations/`
- **Supabase CLI:** Used for local dev and migration management

---

## Schema Reference

### `profiles`
Extends `auth.users`. Created automatically on user registration via trigger.
```sql
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'mentor', 'admin')),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### `courses`
```sql
CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  thumbnail_url TEXT,
  is_published BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### `modules`
```sql
CREATE TABLE modules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### `lessons`
```sql
CREATE TABLE lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id UUID NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('video', 'text', 'flashcard_deck', 'submission_prompt')),
  content TEXT,                  -- markdown or HTML for text lessons
  cloudflare_video_id TEXT,      -- for video lessons
  position INTEGER NOT NULL DEFAULT 0,
  is_published BOOLEAN DEFAULT false,
  is_preview BOOLEAN DEFAULT false,  -- free preview accessible without purchase
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### `purchases`
```sql
CREATE TABLE purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  stripe_session_id TEXT UNIQUE NOT NULL,
  stripe_payment_intent_id TEXT,
  amount_total INTEGER,           -- in centavos (BRL)
  currency TEXT DEFAULT 'brl',
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'refunded', 'revoked')),
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### `purchase_items`
```sql
CREATE TABLE purchase_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_id UUID REFERENCES purchases(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id),
  course_id UUID REFERENCES courses(id),
  purchase_type TEXT NOT NULL CHECK (purchase_type IN ('course', 'mentoring_package', 'bundle')),
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### `pending_purchases`
Email-keyed pre-auth purchases. Claimed on first login.
```sql
CREATE TABLE pending_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  course_id UUID REFERENCES courses(id),
  stripe_session_id TEXT UNIQUE NOT NULL,
  purchase_type TEXT NOT NULL,
  amount_total INTEGER,
  created_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ DEFAULT (now() + INTERVAL '30 days')
);
```

### `flashcard_decks`
```sql
CREATE TABLE flashcard_decks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_id UUID REFERENCES lessons(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### `flashcards`
```sql
CREATE TABLE flashcards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  deck_id UUID NOT NULL REFERENCES flashcard_decks(id) ON DELETE CASCADE,
  front TEXT NOT NULL,
  back TEXT NOT NULL,
  position INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### `user_card_progress`
SM-2 algorithm state per user per card.
```sql
CREATE TABLE user_card_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  card_id UUID NOT NULL REFERENCES flashcards(id) ON DELETE CASCADE,
  ease_factor FLOAT DEFAULT 2.5,
  interval_days INTEGER DEFAULT 1,
  next_review_at TIMESTAMPTZ DEFAULT now(),
  repetitions INTEGER DEFAULT 0,
  last_reviewed_at TIMESTAMPTZ,
  UNIQUE(user_id, card_id)
);
```

### `submissions`
```sql
CREATE TABLE submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  lesson_id UUID NOT NULL REFERENCES lessons(id),
  type TEXT NOT NULL CHECK (type IN ('text_analysis', 'micro_speech')),
  content TEXT,                   -- text submissions
  media_url TEXT,                 -- audio/video submissions
  status TEXT DEFAULT 'submitted' CHECK (status IN ('submitted', 'under_review', 'returned', 'approved')),
  submitted_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### `submission_feedback`
```sql
CREATE TABLE submission_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id UUID NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES auth.users(id),
  content TEXT NOT NULL,
  grade TEXT,                     -- optional: A/B/C or 1-10
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### `mentoring_applications`
```sql
CREATE TABLE mentoring_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  stripe_session_id TEXT UNIQUE,  -- interview fee payment
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'completed')),
  calcom_booking_uid TEXT,
  notes TEXT,                     -- admin notes
  applied_at TIMESTAMPTZ DEFAULT now(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES auth.users(id)
);
```

### `leads`
```sql
CREATE TABLE leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  quiz_responses JSONB,
  diagnosis TEXT,
  score INTEGER,
  source TEXT DEFAULT 'typebot',
  converted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### `stripe_events_log`
For webhook idempotency.
```sql
CREATE TABLE stripe_events_log (
  event_id TEXT PRIMARY KEY,
  processed_at TIMESTAMPTZ DEFAULT now()
);
```

---

## Row-Level Security Policies

### Core Principle
> Users can only read/write their own data. Admins can read/write everything. Service role bypasses RLS.

```sql
-- profiles: users read own, admin reads all
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own profile" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admins full access" ON profiles USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- courses: public read published, admin write all
CREATE POLICY "Public read published courses" ON courses FOR SELECT USING (is_published = true);

-- purchase_items: users read own
CREATE POLICY "Users read own purchases" ON purchase_items FOR SELECT USING (auth.uid() = user_id);

-- user_card_progress: users read/write own
CREATE POLICY "Users own card progress" ON user_card_progress 
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- submissions: users read/write own; admins read all
CREATE POLICY "Users own submissions" ON submissions 
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
```

---

## Indexes

```sql
-- Purchase lookups
CREATE INDEX idx_purchase_items_user_id ON purchase_items(user_id);
CREATE INDEX idx_purchase_items_course_id ON purchase_items(course_id);
CREATE INDEX idx_pending_purchases_email ON pending_purchases(email);

-- Flashcard review queue
CREATE INDEX idx_user_card_progress_next_review ON user_card_progress(user_id, next_review_at);

-- Submissions by lesson
CREATE INDEX idx_submissions_lesson_id ON submissions(lesson_id);
CREATE INDEX idx_submissions_user_id ON submissions(user_id);

-- Leads by email
CREATE INDEX idx_leads_email ON leads(email);

-- Modules/lessons ordering
CREATE INDEX idx_modules_course_position ON modules(course_id, position);
CREATE INDEX idx_lessons_module_position ON lessons(module_id, position);
```

---

## Triggers

```sql
-- Auto-create profile on new user
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Auto-update updated_at columns
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to: profiles, courses, lessons, submissions, leads
```

---

## Migration Conventions

- File naming: `YYYYMMDDHHMMSS_description.sql`
- Never destructively alter a column in production — add new column, migrate data, drop old column in separate migrations
- Always include `ROLLBACK` notes in migration comments
- Test migrations against a local Supabase instance before deploying

---

## DBA Checklist (per schema change)

- [ ] RLS enabled on new tables
- [ ] Policies cover: SELECT / INSERT / UPDATE / DELETE per role
- [ ] Foreign keys with correct `ON DELETE` behavior
- [ ] Indexes on all foreign key columns used in JOINs
- [ ] Indexes on columns used in WHERE clauses of frequent queries
- [ ] `updated_at` trigger on mutable tables
- [ ] No sensitive data stored unencrypted
- [ ] Migration file versioned and tested locally
- [ ] Architect Agent reviewed before deploying to production
