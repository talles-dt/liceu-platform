# Liceu Underground — LMS Project Master Document

> **Version:** 1.0  
> **Last Updated:** 2026-03  
> **Owner:** Talles Diniz Tonatto (Timon)  
> **Status:** Production (active development)

---

## 1. Project Overview

**Liceu Underground** is a Portuguese-language professional training and rhetoric school offering structured education in persuasion, argumentation, public speaking, and written expression. The pedagogical tradition draws from the classical rhetorical canon — Cicero, Quintilian, Aristotle — integrated with a contemporary professional development context.

The LMS (Learning Management System) is the school's primary digital infrastructure: a full-stack web application that hosts courses, manages student access, processes payments, delivers video content, and provides interactive learning tools including spaced repetition flashcards and speech/text submission exercises.

---

## 2. Mission & Pedagogical Identity

- Teach rhetoric as a living discipline, not academic exercise
- Ground instruction in the classical trivium (grammar, logic, rhetoric)
- Serve working professionals in Brazil and the Lusophone world
- Blend structured self-paced learning with live mentoring
- Develop orators who can think, write, argue, and speak with precision and force

---

## 3. Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| Framework | Next.js 16 (App Router) | Full-stack SSR/SSG/ISR web app |
| Auth + DB | Supabase | Authentication, PostgreSQL database, Row-Level Security |
| Payments | Stripe | Checkout, subscriptions, coupons, webhooks |
| Email | Resend | Transactional emails (welcome, receipts, notifications) |
| Video | Cloudflare Stream | Signed JWT video delivery, adaptive streaming |
| Hosting | Vercel | CI/CD deployment, edge functions, env management |
| Scheduling | Cal.com | Mentoring interview booking |
| Chatbot/Funnel | Typebot | Email diagnosis funnel, webhook to Supabase |
| CMS (Blog) | Markdown files + gray-matter | Blog posts stored as `.md` files, parsed at build |
| Styling | Tailwind CSS | Utility-first design system |

---

## 4. Core Systems & Features

### 4.1 Authentication
- Supabase Auth (email/password)
- Protected routes via Next.js middleware
- Session management with server-side cookies
- Role-based access: `student`, `mentor`, `admin`

### 4.2 Purchase & Access Gating
- **Pre-registration flow:** User pays via Stripe Checkout before creating an account (email-keyed pending purchase record)
- **Purchase claiming:** On first login, system detects pending purchase by email and links it to the new user account
- **Access gating:** Lesson viewer checks purchase type against lesson requirements before rendering content
- **Coupon support:** Stripe coupon codes with percentage and fixed discounts
- **Purchase types:** à la carte courses, mentoring packages, bundles

### 4.3 Mentoring Pipeline
- Interview fee payment via Stripe (separate SKU from course purchase)
- Cal.com integration for scheduling mentoring interview slot
- Admin dashboard: approve or reject mentoring candidates
- Approval triggers Resend email with next steps
- Rejection triggers Resend email with explanation template

### 4.4 Video Delivery
- Videos hosted on Cloudflare Stream
- Signed JWT tokens generated server-side per-session (short expiry)
- Player embedded in lesson viewer
- No direct video URL exposed to client

### 4.5 Spaced Repetition Flashcards (SM-2)
- Custom SM-2 algorithm implementation
- Card deck per lesson or module
- Review queue surfaced on student dashboard
- Ease factor and interval stored per card per user in Supabase

### 4.6 Structured Text Analysis Submissions
- Students submit written analyses of canonical texts
- Admin/mentor can review, annotate, and grade
- Submission stored in Supabase with status tracking (`submitted`, `under_review`, `returned`, `approved`)

### 4.7 Micro Speech Submissions
- Students record or upload short audio/video speeches
- Tied to specific lesson prompts
- Stored via Cloudflare or Supabase Storage
- Mentor feedback attached to submission record

### 4.8 Blog CMS
- Posts written in Markdown with frontmatter (title, date, author, tags, excerpt)
- Parsed at build time via `gray-matter`
- Slug-based routing via App Router dynamic segments
- SEO metadata generated from frontmatter

### 4.9 Typebot Email Diagnosis Funnel
- Typebot flow captures lead email + quiz responses
- Webhook fires to Next.js API route
- API route upserts lead record in Supabase
- Triggers Resend welcome/diagnostic email sequence

### 4.10 Admin Content Editor
- Rich admin panel for managing courses, modules, and lessons
- CRUD for course structure (course → module → lesson hierarchy)
- Lesson types: `video`, `text`, `flashcard_deck`, `submission_prompt`
- Cloudflare Stream video ID field per lesson
- Publish/draft toggle per lesson and course

### 4.11 Student Dashboard
- Enrolled courses with progress indicators
- Flashcard review queue
- Pending submissions and feedback
- Upcoming mentoring sessions (via Cal.com embed or link)

---

## 5. Data Architecture (High-Level)

```
users (Supabase Auth)
  └── profiles (extended user data: role, name, phone)
  
courses
  └── modules
        └── lessons (type: video | text | flashcard | submission)

purchases
  └── purchase_items (links purchase → course/package)
  
pending_purchases (pre-auth purchases, keyed by email)

flashcard_decks
  └── flashcards
        └── user_card_progress (SM-2 state per user per card)

submissions (text_analysis | micro_speech)
  └── submission_feedback

mentoring_applications
  ├── interview_payment (Stripe)
  └── schedule_link (Cal.com)

leads (from Typebot funnel)

blog_posts (file system, not DB)
```

---

## 6. Environment Variables

| Variable | Service | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase | Client-side DB URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase | Client-side anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase | Server-side admin key |
| `STRIPE_SECRET_KEY` | Stripe | Server-side Stripe operations |
| `STRIPE_WEBHOOK_SECRET` | Stripe | Webhook signature verification |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | Stripe | Client-side Stripe.js |
| `RESEND_API_KEY` | Resend | Email sending |
| `CLOUDFLARE_ACCOUNT_ID` | Cloudflare | Stream API |
| `CLOUDFLARE_STREAM_API_TOKEN` | Cloudflare | Signed JWT generation |
| `NEXT_PUBLIC_CALCOM_LINK` | Cal.com | Scheduling embed URL |

> ⚠️ All secrets must be set in Vercel Dashboard. Changes to env vars require a redeploy to take effect.

---

## 7. Deployment

- **Platform:** Vercel (production branch: `main`)
- **Build command:** `next build`
- **Node version:** 20.x
- **Edge functions:** Used for middleware (auth protection)
- **Known gotcha:** Env var changes require manual redeploy trigger in Vercel dashboard

---

## 8. Known Issues & Technical Debt

| Issue | Status | Notes |
|---|---|---|
| YAML date parsing in gray-matter | Resolved | Dates must be quoted strings in frontmatter |
| `typedRoutes` compilation errors | Resolved | Disabled in `next.config.js` pending upstream fix |
| Server-side PDF generation | Pivoted | Replaced with print-ready HTML approach |
| Vercel env var rebuild issue | Documented | Env changes need manual redeploy |

---

## 9. Roadmap (Pending / Planned)

- [ ] Certificate generation on course completion (print-ready HTML → PDF)
- [ ] Student progress analytics dashboard (admin)
- [ ] Email drip campaigns via Resend sequences
- [ ] Mobile-responsive polish pass
- [ ] Affiliate/referral system
- [ ] Community forum or cohort discussion threads
- [ ] Live webinar integration (Zoom or similar)
- [ ] Multilingual support (Spanish expansion)
- [ ] A/B testing for landing pages
- [ ] SEO audit and structured data (JSON-LD)

---

## 10. Project Contacts

| Role | Person |
|---|---|
| Founder / Product Owner | Talles Diniz Tonatto (Timon) |
| Platform | liceuunderground.com.br *(confirm)* |

---

## 11. Agent Index

| Agent File | Responsibility Domain |
|---|---|
| `agents/ARCHITECT_AGENT.md` | System design, tech decisions, integration oversight |
| `agents/FRONTEND_AGENT.md` | Next.js pages, components, routing, client UX |
| `agents/BACKEND_AGENT.md` | API routes, server actions, business logic, integrations |
| `agents/DBA_AGENT.md` | Supabase schema, RLS policies, migrations, performance |
| `agents/UIUX_AGENT.md` | User flows, wireframes, interaction design |
| `agents/DESIGN_AGENT.md` | Visual identity, Tailwind tokens, component aesthetics |
| `agents/SECURITY_AGENT.md` | Auth hardening, RLS, secrets, OWASP compliance |
| `agents/PEDAGOGICAL_AGENT.md` | Curriculum structure, learning logic, content standards |
| `agents/MARKETING_AGENT.md` | Funnel, SEO, copy, email sequences, Typebot |
| `agents/FINANCE_AGENT.md` | Stripe config, pricing, revenue logic, reporting |
